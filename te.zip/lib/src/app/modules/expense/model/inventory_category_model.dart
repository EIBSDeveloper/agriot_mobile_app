class InventoryCategoryModel {
  InventoryCategoryModel({
    required this.id,
    required this.name,
    required this.inventoryTypeId,
  });

  factory InventoryCategoryModel.fromJson(Map<String, dynamic> json) =>
      InventoryCategoryModel(
        id: json['id'] ?? 0,
        name: json['name'] ?? '',
        inventoryTypeId: json['inventory_type_id'] ?? 0,
      );
  final int id;
  final String name;
  final int inventoryTypeId;
}
