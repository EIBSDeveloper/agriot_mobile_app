class DocumentView {
  String label;
  String url;
  DocumentView({required this.label, required this.url});
}
