
abstract class NamedItem {
  int get id;
  String get name;
}
