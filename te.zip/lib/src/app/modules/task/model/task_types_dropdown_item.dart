import 'package:argiot/src/app/service/utils/enums.dart';

class TaskTypesDropdownItem {
  final TaskTypes task;
  final String name;

  TaskTypesDropdownItem({required this.task, required this.name});
}
