import 'package:argiot/src/app/modules/near_me/views/widget/custom_app_bar.dart';
import 'package:argiot/src/app/modules/vendor_customer/model/vendor_customer.dart';
import 'package:argiot/src/app/modules/vendor_customer/controller/vendor_customer_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../routes/app_routes.dart';
import '../../../../service/utils/pop_messages.dart';
import '../../../../service/utils/utils.dart';
import '../../../../widgets/toggle_bar.dart';
import '../../../dashboad/view/widgets/buttom_sheet_scroll_button.dart';
import '../../../subscription/model/package_usage.dart';

class VendorCustomerListView extends GetView<VendorCustomerController> {
  const VendorCustomerListView({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: CustomAppBar(title: 'vendor_customer'.tr),
    body: RefreshIndicator(
      onRefresh: () => controller.fetchVendorCustomerList(),
      child: Column(
        children: [
          _buildFilterRow(),
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return const Center(child: CircularProgressIndicator());
              }
              return ListView.builder(
                physics: const AlwaysScrollableScrollPhysics(),
                itemCount: controller.vendorCustomerList.length,
                itemBuilder: (context, index) {
                  final item = controller.vendorCustomerList[index];
                  return _buildListItem(item!);
                },
              );
            }),
          ),
        ],
      ),
    ),
    floatingActionButton: FloatingActionButton(
      backgroundColor: Get.theme.primaryColor,
      onPressed: () async {
        PackageUsage? package = await findLimit();
        if (package!.customerBalance > 0) {
          _showAddDialog();
        } else {
          showDefaultGetXDialog('vendor_customer'.tr);
        }
      },
      child: const Icon(Icons.add),
    ),
  );

  Widget _buildFilterRow() => Padding(
    padding: const EdgeInsets.all(8.0),
    child:Obx(()=> ToggleBar(
      onTap: (index) {
        controller.selectedFilter.value = index;
        controller.fetchVendorCustomerList();
      },
      activePageIndex: controller.selectedFilter.value,
      buttonsList: ["customer".tr, "vendor".tr],
    )),
  );


  Widget _buildListItem(VendorCustomer item) => Card(
    elevation: 1,
    margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    child: ListTile(
      title: Text(item.name, style: Get.textTheme.titleMedium),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (item.shopName != null && item.shopName != '')
            Text(item.shopName!),
          if (item.businessName != null && item.businessName != '')
            Text(item.businessName!),
          if (item.market != null && item.market != '') Text(item.market!),
          if (item.inventoryType != null)
            Text(
              item.inventoryType!,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
        ],
      ),
      trailing: IconButton(
        onPressed: () {
          makePhoneCall(item.mobileNo);
        },
        icon: Icon(Icons.call, color: Get.theme.primaryColor),
      ),
      onTap: () =>
          Get.toNamed( Routes.vendorCustomerDetails, arguments: {'id': item.id}),
    ),
  );

  void _showAddDialog() {
    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.all(16),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
        ),
        height: 400,
        child: Column(
          children: [
            const ButtomSheetScrollButton(),
            Text(
              'add_new'.tr,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            ListTile(
              title: Text('customer'.tr),
              leading: const Icon(Icons.person),
              onTap: () {
                Get.back();
                controller.selectedType.value = 'customer';
                Get.toNamed( Routes.addVendorCustomer);
              },
            ),
            ListTile(
              title: Text('vendor'.tr),
              leading: const Icon(Icons.store),
              onTap: () {
                Get.back();
                controller.selectedType.value = 'vendor';
                Get.toNamed( Routes.addVendorCustomer,);
              },
            ),
          ],
        ),
      ),
      isScrollControlled: true,
    );
  }
}
