class AppIcons {
  //  icon
  static const String home = "assets/icon/home.png";
  static const String inventory = "assets/icon/nearBy.png";
  static const String myCrop = "assets/icon/myCrop.png";
  static const String expense = "assets/icon/expense.png";
  static const String task = "assets/icon/task.png";
  static const String map = "assets/icon/map.png";
  static const String landMark = "assets/image/land_mark.jpg";
}
